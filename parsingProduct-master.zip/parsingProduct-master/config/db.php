<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=irb',
    'username' => 'root',
    'password' => 'qwerty',
    'charset' => 'utf8',
];
